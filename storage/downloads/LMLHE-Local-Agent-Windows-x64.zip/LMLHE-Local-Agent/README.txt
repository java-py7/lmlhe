=======================================================
  Large-Model-on-Light-Hardware Engine: Local PC Agent
  Version 2.0.0 (Standalone Distribution)
=======================================================

HOW TO USE:
1. Double-click "LMLHE-Agent.exe" (or "Start-Agent.bat").
2. The agent will run securely on your computer on port 8008.
3. Open your web dashboard. It will automatically connect and
   detect your physical CPU, RAM, discrete GPU, and local models.

NOTES:
- Fully standalone: No Python installation or terminal needed.
- Connects securely using browser Private Network Access (PNA).
- To stop the agent, close its window or end the task.
=======================================================
